const express = require('express');
const cors = require('cors');
const mysql = require('mysql');


const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: '34.16.126.85',
  user: 'root',
  password: 'demo123',
  database: 'steamdatabase'
})


app.listen(3005, ()=> {
  console.log("connected to backend on port 3005")
})

app.get("/", (req, res) => {
  res.json("hello");
});



app.post("/signup", (req, res) => {
  
  const q = "INSERT INTO User(`email`, `password`, `phone`) VALUES (?)";
  const values = [
    req.body.email,
    req.body.password,
    req.body.phone
  ];

  db.query(q, [values], (err, data) => {
    if (err) return res.send(err);
    return res.json(data);
  });

});


app.post("/signin", (req, res) => {
  const q = `SELECT * FROM User WHERE email = "${req.body.email}" AND password = "${req.body.password}"`;

  db.query(q, (err, data) => {
    if (err) return res.send(err);
    if (data == null) return res.status(400).send("Cannot Find User");

    try {
      if (data.length > 0) {
        res.status(200).json({ message: "User Found", userId: data[0].user_Id });
      }
    } catch {
      res.status(500).send("Wrong Password or Email")
    }
  });
});




app.get('/games/:offset', (req, res) => {
  const skip = req.params.offset ? req.params.offset : 0;
  const q = `SELECT * FROM Games LIMIT 10 offset ${skip}`;
  db.query(q, (err, data) => {
    if (err) return res.send(err);
    return res.json(data);
  });
}); //generally return games without any alterations


app.get('/games/:offset/:searchvalue/:searchtype', (req, res) => {
  const skip = req.params.offset ? req.params.offset : 0;
  const stringvalue = (req.params.searchvalue === "empty")?  "" : req.params.searchvalue;
  const typevalue = req.params.searchtype ? req.params.searchtype : "game_Name";
  
  const q = `SELECT * FROM Games WHERE ${typevalue} LIKE '${stringvalue}%' LIMIT 10 offset ${skip}`;


  db.query(q, (err, data) => {
    if (err) return res.send(typevalue + " " + stringvalue + " " + skip);
    return res.json(data);
  });
}); //generally return games without any alterations


app.get('/preferences/:offset/:searchvalue/:searchtype/:useridentity', (req, res) => {
  const skip = req.params.offset ? req.params.offset : 0;
  const stringvalue = (req.params.searchvalue === "empty")?  "" : req.params.searchvalue;
  const typevalue = req.params.searchtype ? req.params.searchtype : "game_Name";
  const userident = req.params.useridentity ? req.params.useridentity : 0;

  
  const q = 
    `SELECT games_Id, game_Name, description, release_Date, languages, GameImage, phasetwo.user_Id, user_rating, phasetwo.grade, initial_Price, final_Price, message
    FROM Price_Range
       JOIN (SELECT games_Id, game_Name, description, release_Date, languages, GameImage, user_Id, user_rating, Games.grade
        FROM Games
        JOIN (SELECT * FROM Preferences WHERE user_Id = ${userident} ) AS turtles
        ON turtles.game_Id = games_Id
        WHERE Games.${typevalue} LIKE '${stringvalue}%' LIMIT 10 offset ${skip}) AS phasetwo
    ON Price_Range.grade = phasetwo.grade
    JOIN UserMessages ON UserMessages.game_Id = phasetwo.games_Id AND UserMessages.user_Id = phasetwo.user_Id`;
  db.query(q, (err, data) => {
    if (err) return res.send(typevalue + " " + stringvalue + " " + skip);
    
    return res.json(data);
  });
});





app.post('/preferences/:userval/:itemid/:gradeid', (req, res) => {
  const useridentifier = req.params.userval ? req.params.userval : 0;
  const gameidentifier = req.params.itemid ? req.params.itemid : 0;
  const gradeidentifier = req.params.gradeid ? req.params.gradeid : 0;
  
  
  const q = "INSERT INTO Preferences(`user_Id`, `game_Id` , `grade`, `user_rating`) VALUES (?)";
  const values = [
    useridentifier,
    gameidentifier,
    gradeidentifier,
    5
  ];

  db.query(q, [values], (err, data) => {
    if (err) return res.send(err);
    return res.json(data);
  });
});



app.delete('/preferences/:userval/:itemid/:gradeid', (req, res) => {
  const useridentifier = req.params.userval ? req.params.userval : 0;
  const gameidentifier = req.params.itemid ? req.params.itemid : 0;
  const gradeidentifier = req.params.gradeid ? req.params.gradeid : 0;
  
  const q = `DELETE FROM Preferences WHERE user_Id = ${useridentifier} AND game_Id = ${gameidentifier} AND grade = ${gradeidentifier}`;
  
  
  db.query(q, (err, data) => {
    if (err) return res.send(err);
    
    return res.json(data);
  });

});


app.delete('/messages/:userval/:itemid', (req, res) => {
  const useridentifier = req.params.userval ? req.params.userval : 0;
  const gameidentifier = req.params.itemid ? req.params.itemid : 0;
  
  const q = `DELETE FROM UserMessages WHERE user_Id = ${useridentifier} AND game_Id = ${gameidentifier}`;
  
  
  db.query(q, (err, data) => {
    if (err) return res.send(err);
    
    return res.json(data);
  });

});



app.patch('/preferences/:userval/:itemid/:rating', (req, res) => {
  const useridentifier = req.params.userval ? req.params.userval : 0;
  const gameidentifier = req.params.itemid ? req.params.itemid : 0;
  const ratingidentifier = req.params.rating ? req.params.rating : 0;

  const q = 
    `UPDATE Preferences
    SET user_rating = ${ratingidentifier}
    WHERE user_Id = ${useridentifier} AND game_Id = ${gameidentifier}`;

  console.log(req.params.rating)
  console.log(q)

  db.query(q, (err, data) => {
    if (err) return res.send(err);
    return res.json(data);
  });
});


app.get('/recommendations/:userval', (req, res) => {

  const useridentifier = req.params.userval ? req.params.userval : 1;

  const q = 
    `CALL RecommendGamesBasedOnUserPreferences(${useridentifier})`;

  db.query(q, (err, data) => {
    if (err) return res.send(err);
    return res.json(data);
  });
});


