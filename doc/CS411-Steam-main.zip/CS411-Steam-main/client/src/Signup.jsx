import { useState } from 'react'
import './App.css'
import {Link} from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axios from "axios"


const Signup = () => {

    const [signupemail, setEmail] = useState("");
    const [signuppassword, setPassword] = useState(0);
    const [signupphone, setPhone] = useState("");


    const navigate = useNavigate();

    const handleSignInClick = () => {
        navigate('/signin');
    };

    const handlesignup = async () => {
        try {
            await axios.post('http://localhost:3005/signup', {
                email: signupemail,
                password: signuppassword,
                phone: signupphone
              });
            console.log("user has been created");
          } catch (err) {
            console.log(err);
          }
    }

  return (
    <>
        <meta charSet="UTF-8"/>
        <meta httpEquiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel = "stylesheet" href = "style.css"/>
        <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/> 
        <title>Steam Recommender Login Page | Team 101</title>

    
        <div className="container" id="container">
            <div className={`form-container sign-in`}>
                <form>
                    <h1>Create Account</h1>
                    <div className="social-icons">
                        <a href="#" className="icon"><i className="fa-brands fa-google-plus-g"></i></a>
                        <a href="#" className="icon"><i className="fa-brands fa-facebook-f"></i></a>
                        <a href="#" className="icon"><i className="fa-brands fa-github"></i></a>
                        <a href="#" className="icon"><i className="fa-brands fa-linkedin-in"></i></a>
                    </div>
                    <span>or use your email for registeration</span>
                    <input type="text" placeholder="Phone" onChange={(event) => {setPhone(event.target.value);}}/>
                    <input type="email" placeholder="Email" onChange={(event) => {setEmail(event.target.value);}}/>
                    <input type="password" placeholder="Password" onChange={(event) => {setPassword(event.target.value);}}/>
                    <button onClick={handlesignup}>Sign Up</button>
                </form>
            </div>
            
            <div className="toggle-container">
                <div className="toggle">
                    <div className="toggle-panel toggle-left">
                        <h1>Welcome Back!</h1>
                        <p>Enter your personal details to use all of site features</p>
                        <button className="hidden" onClick={handleSignInClick} >Sign In</button>
                    </div>
                </div>
            </div>
            
            
        </div>
    </>
  )
  
}

export default Signup