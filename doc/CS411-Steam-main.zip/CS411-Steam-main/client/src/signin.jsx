import { useState } from 'react'
import './App.css'
import {Link} from 'react-router-dom';
import  {useNavigate} from 'react-router-dom';
import axios from 'axios';



const Signin = () => {

    const Navigate = useNavigate();

    const handleSignUpClick = () => {
        Navigate('/Signup');
    };

    const [loginemail, setlogEmail] = useState("");
    const [loginpassword, setlogPassword] = useState(0);

    const handlesignin = async () => {
        try {
            const user = await axios.post('http://localhost:3005/signin', {
                email: loginemail,
                password: loginpassword
              }).then( res => {
                if (res.status == 200) {
                    localStorage.setItem("userId",res.data.userId)
                    Navigate('/Home');
                } else {
                    console.log(res)

                }

              }
                

              )
              
          } catch (err) {
            console.log(err);
          }
    }

  return (
    <>
      <meta charSet="UTF-8"/>
      <meta httpEquiv="X-UA-Compatible" content="IE=edge"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <link rel = "stylesheet" href = "style.css"/>
      <link rel = "stylesheet" href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/> 
      <title>Steam Recommender Login Page | Team 101</title>
    
    
        <div className="container" id="container">

            <div className={`form-container sign-in`}>
                <form>
                    <h1>Sign In</h1>
                    <div className="social-icons">
                        <a href="#" className="icon"><i className="fa-brands fa-google-plus-g"></i></a>
                        <a href="#" className="icon"><i className="fa-brands fa-facebook-f"></i></a>
                        <a href="#" className="icon"><i className="fa-brands fa-github"></i></a>
                        <a href="#" className="icon"><i className="fa-brands fa-linkedin-in"></i></a>
                    </div>
                    <span>or use your email password</span>
                    <input type="email" placeholder="Email" onChange={(event) => {setlogEmail(event.target.value);}}/>
                    <input type="password" placeholder="Password" onChange={(event) => {setlogPassword(event.target.value);}}/>
                    <a href="#">Forget Your Password?</a>
                    <button onClick={handlesignin} type='button' >Sign In</button>
                </form>
            </div>
            
            <div className="toggle-container">
                <div className="toggle">
                    <div className="toggle-panel toggle-right">
                        <h1>Hello, Friend!</h1>
                        <p>Register with your personal details to use all of site features</p>
                        <button className="hidden" onClick={handleSignUpClick} >Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </>
  )
  
}

export default Signin