import { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Signup from './Signup';
import Signin from './signin';
import Home from './Home';
import Preferences from './Preferences';

function App() {
  return (
    <Router>
      <div className="App">
        <div className="filler">
          <Routes>
            <Route exact path="/" element={<Navigate replace to="/signin" />} />
            <Route exact path="/signin" element={<Signin />} />
            <Route exact path="/Signup" element={<Signup />} />
            <Route exact path="/Home" element={<Home/>} />
            <Route exact path="/Preferences" element={<Preferences/>} />

          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;