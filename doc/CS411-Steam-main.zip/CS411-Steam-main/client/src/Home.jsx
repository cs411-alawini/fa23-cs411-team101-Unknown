import { useState, Fragment } from 'react'
import {Link} from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axios from "axios"

import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import ListItemButton from '@mui/material/ListItemButton';
import {useEffect} from 'react'
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { AppBar, Avatar, Button, Container, IconButton, Snackbar, Stack, TextField, Toolbar } from '@mui/material';
import './Home.css';
import CloseIcon from '@mui/icons-material/Close';
import FavoriteIcon from '@mui/icons-material/Favorite';


const modalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 600,
    height: 500,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    overflow: 'auto'
  };

  const listStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -65%)',
    width: '700px',
    height: '500px',
    bgcolor: 'background.paper',
    p: 4,
    marginTop: '160px',
    overflow: 'auto'
  };

  const buttonStyle = {
    position: 'relative', // Change from absolute to relative
    top: 0,
    left: 0,
    width: '100%',
    backgroundColor: 'inherit',
    zIndex: 1,
  };

  const searchcontainer = {
    position: 'absolute', // Change from absolute to relative
    top: 1,
    left: 0,
    width: '100%',
    backgroundColor: 'inherit',
    bgcolor: 'background.paper',
    zIndex: 1,
    marginTop: '0px',
    height: '140px'
  };

  const searchbar = {
    position: 'absolute', // Change from absolute to relative
    top: '50%',
    left: '50%',
    width: '100%',
    transform: 'translate(0%, -350%)',
    backgroundColor: 'inherit',
    bgcolor: 'grey',
    zIndex: 1,
    marginTop: '0px',
    marginLeft: 'auto'
  };
  

 

const Home = () => {
    const useridentity = localStorage.getItem("userId")

    
    console.log(useridentity)
    const Navigate = useNavigate();

    if (useridentity == null) {
      Navigate('/Signup');
    }

    const handlesignout = () => {
      localStorage.removeItem("userId");
      Navigate('/Signup');
    };

    const handlePrefernces = () => {
      Navigate('/Preferences');
    };

    const [items, setItems] = useState([]);
    const [offset,setoffset] = useState(0);
    const [openModal, setOpenModal] = useState(false);
    const [selectedItem, setSelectedItem] = useState(null);
    const [opennotif, setOpenNotif] = useState(false);
    const [note, setNote] = useState("Notification"); //If we need to correct users if they search wrong values
    const [searchtype, setSearchType] = useState("game_Name");
    const [searchvalue, setSearchValue] = useState(" ");
    const [favcolor, setfavcolor] = useState('inherit');


    function nextten(){
        setoffset(offset + 10)
        console.log(offset)
    };

    function prevten() {
        if (offset >= 10) {
            setoffset(offset - 10)
            console.log(offset)
        };
    } // used for the two buttons to see the next couple options


  useEffect(() => {
    const fetchData = async () => {
      try {
        const games = await axios.get(`http://localhost:3005/games/${offset}/${ (searchvalue.trim().length === 0) ? "empty" : searchvalue.trim()}/${searchtype}`);
        setItems(games.data);
      } catch (error) {
        console.error('Error fetching data: Offset: ' + offset + " searchvalue: " + ( (searchvalue === " " || searchvalue === "") ? "empty" : searchvalue) + " searchtype: " + searchtype, error);
      }
    };

    fetchData();
  }, [offset,searchvalue,searchtype]);

  const removeFromPref = async () => {
    try {
      const lesgo = await axios.delete(`http://localhost:3005/preferences/${useridentity}/${selectedItem.games_Id}/${selectedItem.grade}`);
    } catch (error) {
      console.error('Error fetching data:' , error);
    }
  };

  const addToPref = async () => {
    try {
      const lesgo = await axios.post(`http://localhost:3005/preferences/${useridentity}/${selectedItem.games_Id}/${selectedItem.grade}`);
    } catch (error) {
      console.error('Error fetching data:' , error);
    }
  };

  

  const handleItemClick = (item) => {
    // Handle the click event for each item
    console.log(item)
    setSelectedItem(item);
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setOpenModal(false);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenNotif(false);
  };

  const handleSearchID = () => {
    setSearchType("games_Id")
  }

  const handleSearchName = () => {
    setSearchType("game_Name")
  }

  const handleSearchGrade = () => {
    setSearchType("grade")
  }

  const handleFavorite = () => {
        if (favcolor === 'primary') {
          setfavcolor('inherit')
      } else {
          setfavcolor('primary')
      }

      //call another function that will add it or remove it from preferences
      addToPref()
      setNote(`${selectedItem.game_Name} has been added to preferences`)
    
      setOpenNotif(true);
    console.log(selectedItem);
  }

  const action = (
    <Fragment>
      <Button color="secondary" size="small" onClick={handleClose}>
        UNDO
      </Button>
      <IconButton
        size="small"
        aria-label="close"
        color="inherit"
        onClick={handleClose}
      >
        <CloseIcon fontSize="small" />
      </IconButton>
    </Fragment>
  );

  





    return (
        <>
        
        <Container fixed>
        <AppBar>
          <Toolbar>
            <IconButton size='large' edge='start' color='white' aria-label='logo' onClick={handlesignout}>
            <img width="48" height="48" src="https://img.icons8.com/fluency/48/steam.png" alt="steam"/>
            </IconButton>

            <Typography variant='h6' component='div' sx={{flexgrow: 1}}>
              Sign-Out
            </Typography>
            <Stack direction='row' spacing={2} sx={{marginLeft:'auto'}}>
              <Button color = 'inherit' onClick={handlePrefernces}> Preferences </Button>
            </Stack>
          </Toolbar>
        </AppBar>

        <Container className='searchcontainer' sx={searchcontainer}>
          <Container sx={searchbar}>
            
          </Container>
        </Container>

        <AppBar sx={searchbar}>
          <Toolbar>
            <TextField variant="filled" placeholder="Search Here" onChange={(event) => {setSearchValue(event.target.value);}} sx={{width:"600px"}}>
              Search Query Here
            </TextField>

            <Stack direction='row' spacing={2} sx={{marginLeft:'auto'}}>
            <Typography variant="h6">
              Search By
            </Typography>
              <Button color = 'inherit' onClick={handleSearchName}> Name </Button>
              <Button color = 'inherit' onClick={handleSearchGrade}> Grade </Button>
              <Button color = 'inherit' onClick={handleSearchID}> ID </Button>
            </Stack>

          </Toolbar>
        </AppBar>



        <List sx={listStyle}>
        <Button onClick={prevten} >Prev</Button>
        <Button onClick={nextten} >Next</Button>
          {items.map((item, index) => (
              <ListItem disablePadding key={index}>
                <ListItemButton onClick={() => handleItemClick(item)}>
                <ListItemAvatar><Avatar alt="logo" src={item ? item.GameImage : ''}/></ListItemAvatar>
                  <ListItemText primary={item.game_Name} /> {/* Assuming each item has a 'name' property */}
                  
                </ListItemButton>
              </ListItem>
            ))}
        </List>

        <Modal
            open={openModal}
            onClose={handleCloseModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
            >
            <Box sx={modalStyle}>
                <Typography id="modal-modal-title" variant="h6" component="h2">
                    {selectedItem ? selectedItem.game_Name : ''}
                    <IconButton size="large" aria-label="Favorite" color={favcolor} onClick={handleFavorite}>
                      <FavoriteIcon/>
                    </IconButton>
                </Typography>

                <img src = {selectedItem ? selectedItem.GameImage : ''} alt='' />

                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                    {"Description: "}
                    {selectedItem ? selectedItem.description : ''}
                </Typography>

                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                    {"Release Date: " + (selectedItem ? selectedItem.release_Date : '')}
                </Typography>

                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                    {"Id: " + (selectedItem ? selectedItem.games_Id : '') }
                </Typography>

                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                    {"Languages: " + (selectedItem ? selectedItem.languages : '')}
                </Typography>

                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                    {"Grade: " + (selectedItem ? selectedItem.grade : '')}
                </Typography>

                

            </Box>
        </Modal>

        </Container>


        <Snackbar
        open={opennotif}
        autoHideDuration={6000}
        onClose={handleClose}
        message={note}
        action={action}
      />
      

        
        </>


    );
}

export default Home